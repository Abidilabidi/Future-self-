# Future Self — Unified Intelligence v2

## Qué incluye
- Aplicación web móvil en árabe, español, francés e inglés.
- Panel principal, seguimiento humano, perfiles de perros y gatos.
- Planificador de objetivos, laboratorio de decisiones e historial.
- Almacenamiento local y migración automática de `futureSelfRecords` de la versión anterior.
- Copia de seguridad JSON e importación.
- PWA instalable y caché offline.
- Motor local orientativo y puerta de enlace opcional para IA real.

## Publicación gratuita (frontend)
1. Descomprime este paquete.
2. Sube todos los archivos a la raíz del repositorio `Abidilabidi/Future-self-`.
3. En GitHub: Settings → Pages → Deploy from a branch → `main` → `/ (root)` → Save.
4. Abre la URL de GitHub Pages desde el móvil. Usa el menú del navegador → Añadir a pantalla principal.

## IA conectada de forma segura
El frontend no contiene claves secretas. `worker.js` es una plantilla para Cloudflare Workers:
1. Crea un Worker y pega el contenido de `worker.js`.
2. Configura el secret `OPENAI_API_KEY` en el panel del Worker (nunca en GitHub).
3. Opcional: configura `AI_MODEL` y `ALLOWED_ORIGIN`.
4. Despliega y copia la URL terminada en `/api/ai`.
5. En Future Self → Ajustes, pega esa URL y marca el consentimiento antes de enviar datos.

La aplicación funciona sin Worker: usa análisis local de orientación. La IA conectada requiere una cuenta y un proveedor de IA; el consumo puede tener coste. No se promete servicio de IA externo gratuito.

## Privacidad y límites
- Los registros se guardan en `localStorage` de este navegador/dispositivo.
- Borrar datos del navegador puede borrar los registros; exporta copias periódicamente.
- Los datos sólo salen del dispositivo cuando el usuario pulsa un análisis conectado y ha dado consentimiento.
- No es una herramienta médica ni veterinaria, no diagnostica ni predice el futuro.
- El análisis animal sólo ayuda a observar cambios; ante dolor, dificultad respiratoria, colapso, convulsiones o deterioro rápido, busca atención veterinaria urgente.

## Compatibilidad
HTML/CSS/JavaScript sin dependencias externas. GitHub Pages sirve el frontend estático; el Worker es opcional y separado.
