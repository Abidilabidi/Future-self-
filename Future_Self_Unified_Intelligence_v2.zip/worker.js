// Future Self secure AI gateway — deploy as a Cloudflare Worker.
// Set secrets: OPENAI_API_KEY. Optional vars: AI_MODEL, ALLOWED_ORIGIN.
// Never put API keys in index.html or GitHub.
export default {
 async fetch(request, env) {
  const origin = request.headers.get("Origin") || "";
  const allowed = env.ALLOWED_ORIGIN || "*";
  const headers = {
   "Access-Control-Allow-Origin": allowed === "*" ? "*" : (origin === allowed ? origin : allowed),
   "Access-Control-Allow-Methods": "POST, OPTIONS",
   "Access-Control-Allow-Headers": "Content-Type",
   "Content-Type": "application/json"
  };
  if (request.method === "OPTIONS") return new Response(null,{headers});
  if (new URL(request.url).pathname !== "/api/ai") return new Response(JSON.stringify({error:"Not found"}),{status:404,headers});
  if (request.method !== "POST") return new Response(JSON.stringify({error:"Method not allowed"}),{status:405,headers});
  if (!env.OPENAI_API_KEY) return new Response(JSON.stringify({error:"AI key is not configured"}),{status:503,headers});
  try {
   const body = await request.json();
   const raw = JSON.stringify(body);
   if (raw.length > 16000) return new Response(JSON.stringify({error:"Payload too large"}),{status:413,headers});
   const lang = ({ar:"Arabic",es:"Spanish",fr:"French",en:"English"})[body.language] || "English";
   const system = `You are Future Self, a careful multilingual planning and wellbeing assistant. Reply in ${lang}. Be practical, respectful, concise and uncertainty-aware. Help users understand present patterns, create realistic plans, compare decision scenarios, and observe animal wellbeing. Never claim to predict the future, diagnose a human or animal, or replace a qualified professional. For urgent human danger or animal distress, advise appropriate emergency/professional help. Separate observed facts, possible interpretations, and suggested next steps. Do not invent facts. Ask at most one clarifying question if essential.`;
   const user = `Analyze this Future Self request. Return a structured but readable response with: 1) What the information says, 2) possible patterns/uncertainties, 3) 3 practical next steps, 4) what to monitor. Request data:\n${raw}`;
   const response = await fetch("https://api.openai.com/v1/chat/completions",{
    method:"POST",headers:{"Authorization":`Bearer ${env.OPENAI_API_KEY}`,"Content-Type":"application/json"},
    body:JSON.stringify({model:env.AI_MODEL||"gpt-4.1-mini",temperature:0.4,messages:[{role:"system",content:system},{role:"user",content:user}]})
   });
   const result = await response.json();
   if (!response.ok) return new Response(JSON.stringify({error:result.error?.message||"AI provider error"}),{status:502,headers});
   return new Response(JSON.stringify({output:result.choices?.[0]?.message?.content||"No response"}),{headers});
  } catch(e) { return new Response(JSON.stringify({error:"Invalid request"}),{status:400,headers}); }
 }
};